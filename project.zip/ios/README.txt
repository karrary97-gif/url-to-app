iPhone (IPA) - يتطلب Mac + Xcode + حساب Apple Developer
1) Xcode > New Project > iOS App (SwiftUI)، الاسم: نظام التقديم على الدراسة المسائية ، Bundle ID: com.linkapp.app
2) استبدل ملف *App.swift الموجود بملف App.swift هنا.
3) Assets > AppIcon: اسحب icon-1024.png.
4) General > Version = 1.0.0
5) Product > Archive ثم Distribute App لتصدير IPA.
ملاحظة: استخدم رابط https.
