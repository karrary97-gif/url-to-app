import SwiftUI
import WebKit

@main
struct LinkApp: App {
  var body: some Scene {
    WindowGroup { WebContainer(url: URL(string: "https://eve-system-qpc.netlify.app")!).ignoresSafeArea() }
  }
}

struct WebContainer: UIViewRepresentable {
  let url: URL
  func makeUIView(context: Context) -> WKWebView { WKWebView() }
  func updateUIView(_ v: WKWebView, context: Context) { if v.url == nil { v.load(URLRequest(url: url)) } }
}
