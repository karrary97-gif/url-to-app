const {app,BrowserWindow}=require('electron');
app.whenReady().then(()=>{
  const w=new BrowserWindow({width:1100,height:760,autoHideMenuBar:true,icon:__dirname+'/icon.png'});
  w.loadURL("https://eve-system-qpc.netlify.app");
});
app.on('window-all-closed',()=>app.quit());
