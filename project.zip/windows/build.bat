@echo off
call npm install
call npm run dist
echo الملف النهائي داخل مجلد dist
pause
