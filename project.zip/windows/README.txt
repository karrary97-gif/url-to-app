Windows (EXE)
1) ثبّت Node.js.
2) انقر مرتين على build.bat
3) ستجد ملف exe داخل مجلد dist.
