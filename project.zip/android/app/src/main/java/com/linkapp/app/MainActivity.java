package com.linkapp.app;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
public class MainActivity extends Activity{
  WebView w;
  @Override protected void onCreate(Bundle b){
    super.onCreate(b);
    w=new WebView(this);
    WebSettings s=w.getSettings();
    s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);
    w.setWebViewClient(new WebViewClient());
    w.loadUrl("https://eve-system-qpc.netlify.app");
    setContentView(w);
  }
  @Override public void onBackPressed(){if(w.canGoBack())w.goBack();else super.onBackPressed();}
}
