Android (APK)
1) افتح المجلد في Android Studio.
2) Build > Build APK(s)  (أو Generate Signed Bundle/APK للنشر).
أو من الطرفية: gradle assembleRelease
